function y = BSCChannel(x, p)
% function y = BSCChannel(x, p)
% 
% Description:
% ~~~~~~~~~~~
% This function simulates a BSC channel over a vector
% 
% Inputs:
% ~~~~~~
% x - input vector
% p - channel error probabillity
% 
% Outputs:
% ~~~~~~~
% y - the result of the input vector passing the BSC channel

c = round(0.5*rand(size(x)) + 0.5*p);
y = xor(x, c);