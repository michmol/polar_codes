% % % % % % % % % % % % % % % 
% Polar Code Test Script
% % % % % % % % % % % % % % % 
clc;
clear;

M = 100;%amount of simulation iterations

N = 128;%codeword length
p = 0.1; %probability of error in the BSC channel



ErrorVec = zeros(1,N);
for ind = 1:M
   clc;
   display(['Iteration ', num2str(ind)]);
   
   U = round(rand(1, N));%generate random input vector
   
   X = PolarEncode(U);%polar encoding
   
   Y = bsc(X, p);%pass X through a BSC channel
   
   Utag = PolarDecodeBSC(Y,U,p);%polar decoding
   
   ErrorVec = ErrorVec + double(xor(Utag, U)) / M;
end

P = ErrorVec;
P(P>0.5) = 1-P(P>0.5);

H = p .* log2(1./p) + (1-p).*log2(1./(1-p));
C = 1-H;
Rmax = sum(P<1e-2) / M;

figure;plot(P,'.')
xlabel('Channel Index');
ylabel('Error Probabillity');

