function X = PolarEncode(U)
% function X = PolarEncode(U)
%
% Description:
% ~~~~~~~~~~~
% Perform Polar Encoding using u+v,v kernel

U = U(:)'; %make row vector

if length(U) == 2
    X = zeros(1, 2);
    X(1) = xor(U(1), U(2));
    X(2) = U(2);
else
    X1 = PolarEncode(xor(U(1:2:end), U(2:2:end)));
    X2 = PolarEncode(U(2:2:end));
    X = [X1, X2];
end


