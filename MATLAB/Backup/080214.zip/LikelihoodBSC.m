function L = LikelihoodBSC(Y, p)
switch Y
    case 0
        L = (1 - p)/p;
    otherwise
        L = p/(1 - p);
end
end