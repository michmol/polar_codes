function [I, Z] = BMS_IandZ(W)
% function I = BMS_IandZ(W)
% 
% Decription:
% ~~~~~~~~~~
% Calculate the mutual information of the channel W and the Bhattacharyya
% parameter
% 
% Input: W - the channel matrix
% Output: I - the mutual information
%         Z - the Bhattacharyya parameter

I = sum(sum(0.5 * W .* log2(W ./ repmat(0.5*(W(1,:) + W(2,:)),2,1))));%inner sum is over 'x' and the outer is over 'y')

Z = sum(sqrt(W(1,:) .* W(2,:)));