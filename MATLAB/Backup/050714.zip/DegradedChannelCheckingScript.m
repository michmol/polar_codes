% % % % % % % % % % % % % % % % % % % % % % 
% Check the degrading merge script
% % % % % % % % % % % % % % % % % % % % % % 
clc;
clear;


mu = 256;%bound on the output alphabet size
N = 2^10;%number of bit channel in the polar codind

%Random diecrete cahnnel
%W = randomBMSChannel(N);

%Create Gaussian distribution
SNR = 5;
m = 1;%Expectancy
% s = 1/10^(SNR/10)/2;%Variance
s = 1;
y = linspace(-15, 15 , 1000000);%Argument axis
W = 1/sqrt(2*pi*s^2)*exp(-(y-m).^2/(2*s^2));%Gaussian Distribution

%Gaussian Channel Capacity
I = 0.5 * log2(1 + m/s);

%BSC Channel
% p = 0.001;
% W = [1-p, p; p 1-p];

%find the degraded bit channels for the above distribution
Q = degradedPolarChannel(y, W, mu, N);

IDegraded = zeros(1,N);
ZDegraded = zeros(1,N);
for ind = 1:N
    [IDegraded(ind), ZDegraded(ind)] = BMS_IandZ(Q{ind});
end

% figure;plot(IDegraded,'.');
figure;plot(ZDegraded,'.');