classdef LRListMember < handle
    properties
        a
        b
        a1
        b1
        DeltaI
        h
    end
    properties(SetAccess = private)
        Next
        Prev
    end
    
    methods
        function obj = LRListMember(a, b, a1, b1, DeltaI, h)
            % Object Constructor
            if nargin > 0
                obj.a = a;
                obj.b = b;
                obj.a1 = a1;
                obj.b1 = b1;
                obj.DeltaI = DeltaI;
            end
        end
        
        function insertAfter(newNode, nodeBefore)
            % insertAfter  Inserts newNode after nodeBefore.
            disconnect(newNode);
            newNode.Next = nodeBefore.Next;
            newNode.Prev = nodeBefore;
            if ~isempty(nodeBefore.Next)
                nodeBefore.Next.Prev = newNode;
            end
            nodeBefore.Next = newNode;
        end
        
        function insertBefore(newNode, nodeAfter)
            % insertBefore  Inserts newNode before nodeAfter.
            disconnect(newNode);
            newNode.Next = nodeAfter;
            newNode.Prev = nodeAfter.Prev;
            if ~isempty(nodeAfter.Prev)
                nodeAfter.Prev.Next = newNode;
            end
            nodeAfter.Prev = newNode;
        end
        
        function disconnect(node)
            % DISCONNECT  Removes a node from a linked list.
            % The node can be reconnected or moved to a different list.
            prevNode = node.Prev;
            nextNode = node.Next;
            if ~isempty(prevNode)
                prevNode.Next = nextNode;
            end
            if ~isempty(nextNode)
                nextNode.Prev = prevNode;
            end
            node.Next = [];
            node.Prev = [];
        end
        
        function delete(node)
            % DELETE  Deletes a dlnode from a linked list.
            disconnect(node);
        end
        
    end
end