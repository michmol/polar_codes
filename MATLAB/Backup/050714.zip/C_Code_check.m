clc;

%FilePath = 'C:\Users\Michael\Dropbox\Codes\C Code\DegradedChannel_TV\Debug\DegradedChannels_1024_256_AWGN_1_1.csv';
%FilePath = 'C:\Users\Michael\Dropbox\Codes\C Code\DegradedChannel_TV\Debug\DegradedChannels_1024_256_BSC_001.csv';
FilePath = 'C:\Users\Michael\Dropbox\Codes\C Code\DegradedChannel_TV\Debug\DegradedChannels_1024_512_AWGN_SNR_5.csv';
%FilePath = 'C:\Users\Michael\Dropbox\Codes\C Code\DegradedChannel_TV\Debug\DegradedChannels.csv';

D =  textread(FilePath,'','delimiter',',');

%I = sum(sum(0.5 * W .* log2(W ./ repmat(0.5*(W(1,:) + W(2,:)),2,1))));

Z = zeros(1, size(D,1));
Perr = zeros(1, size(D,1));
for ind = 1:length(Z)
    C = D(ind, :);
    C(C == -1) = [];
    Cconj = fliplr(C);
    
    %    PSym = (Ch + ChConj) * 0.5; %probaility to receive each symbol
    %    PeGivenSym = min(Ch, ChConj) ./ (Ch + ChConj);
    %    Perr(ind) = sum(PeGivenSym .* PSym);
    
    Z(ind) = sum(sqrt(C .* Cconj));
    Perr(ind) = 0.5 * sum(min(C, Cconj));
end

% figure;plot(1:length(Z), Z,'.');
% title('C++ Simulation Z');

figure;plot(1:length(Z), Perr,'.');

ZSort = sort(Perr);
%ZSort = sort(Z);
k = 921 : 1024;
Pe = zeros(size(k));
for ind = 1:length(Pe)
    Pe(ind) = sum(ZSort(1:k(ind)));
end

figure;plot(k/1024, log10(Pe));
axis tight; grid on;
