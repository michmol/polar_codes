% % % % % % % % % % % % % % % 
% Polar Code Test Script
% % % % % % % % % % % % % % % 
clc;
clear;

M = 1000;%amount of simulation iterations

N = 1024;%codeword length
p = 0.001; %probability of error in the BSC channel



ErrorVec = zeros(1,N);
for ind = 1:M
   clc;
   display(['Iteration ', num2str(ind)]);
   
   U = round(rand(1, N));%generate random input vector
   
   X = PolarEncode(U);%polar encoding
   
   Y = bsc(X, p);%pass X through a BSC channel
   
   Utag = PolarDecode(Y,U,p);%polar decoding
   
   ErrorVec = ErrorVec + double(xor(Utag, U)) / M;
end

P = ErrorVec;

H = p .* log2(1./p) + (1-p).*log2(1./(1-p));
C = 1-H;
Rmax = sum(P<1e-2) / M;

figure;plot(P,'.')
xlabel('Channel Index');
ylabel('Error Probabillity');

