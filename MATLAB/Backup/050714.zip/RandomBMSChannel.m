function W = RandomBMSChannel(N)
% function W = RandomBMSChannel(N)
% 
% Deescription:
% ~~~~~~~~~~~~
% Generate a random channel Binary channel with output alphabet size N
% 
% Input: N - desired output alphabet size
% Output - W - the channel

P = rand(1,N);%generate a randon vector of values
P = P/sum(P);%normalize to get a vector of probablillities 
W = [P; fliplr(P)];%W(y|0) = W(y_conj|1)